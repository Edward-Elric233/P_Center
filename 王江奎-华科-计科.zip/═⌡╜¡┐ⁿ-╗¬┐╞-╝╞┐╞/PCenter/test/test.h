// Copyright(C), Edward-Elric233
// Author: Edward-Elric233
// Version: 1.0
// Date: 2022/6/27
// Description: 
#ifndef P_CENTER_TEST_H
#define P_CENTER_TEST_H

namespace edward {

void test_Set();

}

#endif //P_CENTER_TEST_H
